﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationSpeed : MonoBehaviour {

	public Animation anim;

	// Use this for initialization
	void Start () {
		anim ["Up_Idle"].speed = 0.5f;
	}
	

}
