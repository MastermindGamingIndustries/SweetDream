﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
//Author:Jonathon Hartman
//Date:10/15/17
//Credit:Shawn Kendall
//credit:Unity Answer user Puck @ http://answers.unity3d.com/questions/857827/pick-random-point-on-navmesh.html
//Purpose: to create a functioning AI

public class NavAgent : MonoBehaviour {

	public NavMeshAgent myNavAgent;
	[SerializeField] NavPoint[]	myNavPoints;
	public bool Ontrigger = true;
	public GameObject prefab;
	int navIndex = 0;
	[SerializeField] private float waitTime;
	private float timePassed = 0.0f;
	GuardStateMachine state;


	// Use this for initialization
	void Start () {
		myNavAgent = GetComponent<NavMeshAgent> ();
		//myNavPoints = FindObjectsOfType<NavPoint>();
		//myNavAlarm = FindObjectsOfType<GameObject>();
		navIndex = 0;
		FindDestination ();
		// Resets timer
		ResetTimeSinceLastTransition();
	}

	public void FindDestination (){
		Vector3 newTravelPosition = myNavPoints [navIndex].transform.position;

		myNavAgent.SetDestination (newTravelPosition);
	}
	public void OnTriggerEnter(){
		
		print ("Idle State");

		Ontrigger = true;

		++navIndex;

		if (navIndex >= myNavPoints.Length)
			navIndex = 0;
	
 		FindDestination ();
	}

	public void OnTriggerExit(){

		print ("to the next location");
		Ontrigger = false;
	} 
	public float GetTime(){
		return timePassed;
	}
	public float GetWaitTime(){
		return waitTime;
	}
	// Update is called once per frame
	void Update () {
		timePassed += Time.deltaTime;
	}
	// Resets the transition timer
	public void ResetTimeSinceLastTransition()
	{
		timePassed = 0.0f;
	}
}
