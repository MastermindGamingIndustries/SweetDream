﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileMoving : MonoBehaviour {

	[SerializeField]
	GameObject Boss1;
	[SerializeField]
	GameObject Boss2;

	public float speed;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		move ();
	}
	void move(){
		if (Boss1) {
			transform.Translate (Vector3.right * Time.deltaTime * speed);
		}
		if (Boss2) {
			transform.Translate (Vector3.left * Time.deltaTime * speed);
		}
	}
	void OnTriggerEnter2D(Collider2D other){
		if (other.tag == "NoPass") {
			Destroy (this.gameObject); 
		}
	}
}
