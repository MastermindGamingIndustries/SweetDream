﻿//Author: Jonathon Hartman
//Date: 3/30/2017
//Credit: https://www.youtube.com/playlist?list=PLbghT7MmckI4IeNHkPm5bFJhY9GQ0anKN
//Credit: quill18creates
//Purpose: Damage control

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damage : MonoBehaviour {

	public int health =1;

	public float intanPeriod = 0;
	float intan = 0;
	int DefultLayer;

	void Start(){
		DefultLayer = gameObject.layer;
	}
	void OnTriggerEnter2D() {

		health--;
		intan = 0.75f;
		gameObject.layer = 10;
	}

	void Update(){

		intan -= Time.deltaTime;
		if (intan <= 0) {
			gameObject.layer = DefultLayer;
		}

		if(health <= 0) {
			Death ();
		}
	}
	void Death(){
		Destroy (gameObject);
	}
}
