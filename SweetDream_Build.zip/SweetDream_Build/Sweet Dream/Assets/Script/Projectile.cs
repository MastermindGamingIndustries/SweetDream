﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour {
	

	//The game object that spawns the bullet
	private Player CupCake;
	//controls game object speed
	public float MoveSpeed = 10.0f;

	public float frequency = 20.0f;  // Speed of sine movement
	public float magnitude = 0.5f;   // Size of sine movement
	private Vector3 axis;

	private Vector3 pos;

	 bool isleft = true;
	[SerializeField]
	EnemyControls Emctrl;
	//boss
	[SerializeField] 
	GameObject Boss;
	public int CurHit;

	public int defeatedEnemies = 0;
	public int CurDefeatedEnemies;
	private SpriteRenderer mySpriteRenderer;
	void Start () {
		pos = transform.position;
		axis = transform.right;  // May or may not be the axis you want

		//find the player game object by name
		GameObject player = GameObject.Find("Player");
        CupCake = player.GetComponent<Player> ();
		mySpriteRenderer = GetComponent<SpriteRenderer> ();

		if (CupCake.isleft == true) {
			isleft = true;
			mySpriteRenderer.flipX = true;
		} else {
			isleft = false;
			mySpriteRenderer.flipX = false;
		}
	}

	void Update () {
	/*pos += transform.right * Time.deltaTime * MoveSpeed;
		transform.position = pos + axis * Mathf.Sin (Time.time * frequency) * magnitude;

		Vector3 pos = transform.right;
		pos.x +=  fullSpeed * Time.deltaTime;
		transform.position = pos; */
	//for movement
		if (isleft == false) {
			pos = MoveSpeed * transform.right;
		} else if (isleft == true) {
			pos = MoveSpeed * -transform.right;
		}
		transform.Translate (pos * Time.deltaTime);
	}

	 void OnBecameInvisible()
	{
		Destroy (gameObject);
	}

	void OnTriggerEnter2D (Collider2D other){
		/* what type of object did we collide with?
		 * is this an enemy?*/
		Debug.Log ("error1");
		if (other.tag == "Ant Enemy") {
			Debug.Log ("Hit enemy!" );
			Destroy(gameObject);
	}
		/*if (other.tag == "Boss")
		{
				Destroy(gameObject);
		}*/
}


	void StartDestroy (float timeDelay) {

		// Turn off drawing and colliding
		GetComponent<Renderer>().enabled = false;
		GetComponent<Collider> ().enabled = false;

		//Start the destroy countdown
		Destroy(gameObject, timeDelay);
	}
}
