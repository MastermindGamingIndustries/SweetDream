﻿//Author: Jonathon Hartman
//Date: 3/31/2017
//Credit: https://www.youtube.com/playlist?list=PLbghT7MmckI4IeNHkPm5bFJhY9GQ0anKN
//Credit: User: quill18creates
//Purpose: making bullets vanish

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet_vanish : MonoBehaviour {

	public float timer = 1f;

	// Use this for initialization
	void Start () {
		Destroy (gameObject, timer);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
