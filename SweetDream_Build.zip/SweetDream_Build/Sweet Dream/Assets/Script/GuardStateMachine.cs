﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//Author:Jonathon Hartman
//date:10/15/17
//Credit:Shawn Kendall
//Credit: youtuber BananaKingGames https://www.youtube.com/watch?v=hyZPpACBW_8
//Purpose: Create a state machine for guard
public class GuardStateMachine : ByTheTale.StateMachine.MachineBehaviour {
	public override void AddStates()
	{
		AddState<PatrolState>();
		AddState<IdleState> ();



		SetInitialState<PatrolState>();
	}
}

public class GuardsState : ByTheTale.StateMachine.State
{
	protected NavAgent Agent;

	public override void Enter()
	{
		Agent = GetMachine<GuardStateMachine>().GetComponent<NavAgent>();
		Agent.ResetTimeSinceLastTransition();

	}
}
public class PatrolState : GuardsState
{
	public override void Enter()
	{
		base.Enter();
		// Sets green light to green
	//	Agent.gameObject.GetComponent<Renderer>().material.color = Color.green;
		Agent.FindDestination();
	}

	public override void Execute()
	{
		if (Agent.Ontrigger == true) {

			//changes to idle state
			machine.ChangeState<IdleState> ();
		}
	}

	public override void Exit()
	{
		// Sets agaent to grey
		//Agent.gameObject.GetComponent<Renderer>().material.color = Color.gray;
	} 
}


public class IdleState : GuardsState
{
	public override void Enter()
	{
		base.Enter();
		// Sets guard to pause
	//	Agent.gameObject.GetComponent<Collider>().isTrigger = true;
		//Agent.gameObject.GetComponent<Renderer>().material.color = new Color32(0,100,0,255);
		Agent.GetComponent<UnityEngine.AI.NavMeshAgent>().enabled = false;
	}

	public override void Execute()
	{
		// Checks to see if the pause key is hit
		if ((Agent.GetTime ()) > (Agent.GetWaitTime ())) {
			Debug.Log ("time reset");
			Agent.GetComponent<UnityEngine.AI.NavMeshAgent> ().enabled = true;
			// Changes to patrol state
			machine.ChangeState<PatrolState> ();
		}
	}
	public override void Exit()
	{
		// Sets agent to grey
		//Agent.gameObject.GetComponent<Renderer>().material.color = Color.gray;
		//Debug.Log("guard movement resumes");
	} 
}





	
