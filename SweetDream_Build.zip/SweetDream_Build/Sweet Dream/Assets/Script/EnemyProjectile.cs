﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : MonoBehaviour {

	[SerializeField] 
	GameObject[] Projectile;
	[SerializeField]
	private Player PlayerCtrl;

    public bool StartTimer = false;
    // Time variance bounds between generating an enemy
    [SerializeField]
	float TimeMin =  1.0f;
	[SerializeField] 
	float TimeMax = 4.0f;

	/* the amount of time to wait between spawning
	 * enemies. populated at spawn time based on a 
	 * random selected between the min and maz. */
	private float TimeLimit = 2f;
	// timer for firing projectile
	private float Timer = 0;
	private Vector3 pos;
	// Use this for initialization
	void Start () {
		pos = transform.position;
        
    }

	// Update is called once per frame
	void Update () {
		updateTimer ();
       
            if (Timer == 0)
            {
                doSpawn();
            }
        

      
    } 
		
	/* Update the spawn timer and check if 
	 * a new enemy should spawn*/
	void updateTimer () {
		//Accumulate time elapsed
		Timer += Time.deltaTime;

		//Reached our time limit
		if (Timer >= TimeLimit) 
		{
			// Generate a new time between our bounds
			TimeLimit = Random.Range( TimeMin , TimeMax );
			// Reset the timer
			Timer = 0;

			//Spawn an enemy
			Debug.Log("Projectile timer spawn test!");
		}
	}
	public void doSpawn (){
        if (StartTimer == true)
        {
            // Randomly choose an index in the enemy array
            int randIndex = Random.Range(0, Projectile.Length);

            /*use the random index to select one of the enemy 
             * types to spawn */
            Instantiate(Projectile[randIndex],
                transform.position, transform.rotation);
        }
	}
	void OnTriggerEnter2D(Collider2D other)
	{
		
	/*	if (other.tag == "Player") {
			PlayerCtrl.levelManager.RespawnPlayer ();
			Debug.Log ("Boss hit = 0");
			AntB.killHitsTaken = 0;
			Destroy (gameObject); 
		}
        */
	}

	void OnBecameInvisible()
	{
		Destroy (gameObject);
	}
	void StartDestroy (float timeDelay) {

		// Turn off drawing and colliding
		GetComponent<Renderer>().enabled = false;
		GetComponent<Collider> ().enabled = false;

		//Start the destroy countdown
		Destroy(gameObject, timeDelay);
	}
}
