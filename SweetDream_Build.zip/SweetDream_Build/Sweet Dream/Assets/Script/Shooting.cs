﻿//Author: Jonathon Hartman
//Date: 3/30/2017
//Credit: https://www.youtube.com/watch?v=1mw1ufZq1N4
//Credit: quill18creates
//Purpose: Shooting
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour {

	public Vector3 bulletOffset = new Vector3 (5 , 0, 0);
	public float fire = 1f;
	float cooldown = 0;

	public GameObject bulletPrefab;

	// Update is called once per frame
	void Update () {
		cooldown -= Time.deltaTime;

		if (Input.GetKeyDown(KeyCode.F) && cooldown <= 0) {
			//shoot
			Debug.Log("fire!");
			cooldown = fire;

			Vector3 offset = new Vector3 (1, 0, 0);

			Instantiate (bulletPrefab, transform.position + offset, transform.rotation);

		}
	}
}
