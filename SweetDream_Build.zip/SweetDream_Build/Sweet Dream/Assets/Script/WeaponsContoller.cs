﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponsContoller : MonoBehaviour {

    [SerializeField]
    public GameObject myBullet;

    [SerializeField]
    //firerate of the multishot
    float fireRate = 0.3f;

    [SerializeField]
    float offset = 0.5f;


    [SerializeField]
    public int maxAmmo = 100;
    public int curAmmo;
  
  
	private Vector3 axis;

	private Vector3 pos;

    // Use this for initialization
    void Start()
    {
		curAmmo = maxAmmo;
    }

  /*  void Update()
    {
		if (Input.GetKeyDown(KeyCode.F))
        {
            InstantiateBullet();
        }
    } */

    public void ModUnload()
    {
        curAmmo = 0;
    }

   /* void InstantiateBullet()
    {
        GameObject bullet = Instantiate(myBullet,transform.position,Quaternion.identity);
	//	bullet.GetComponent<Projectile>().isleft
    }

    void InstantiateBullet(Vector3 pos)
    {
        if (curAmmo > 0)
        {
            Instantiate(myBullet, pos, transform.rotation);
            curAmmo--;
        }
    } */


    public void ModReload()
    {
        curAmmo = maxAmmo;
    }

    public void SingleFire()
    {
    //    InstantiateBullet();
    }
}
