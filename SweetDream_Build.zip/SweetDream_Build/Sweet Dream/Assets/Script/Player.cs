﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

    // refrences the level manager script
    public LevelManager levelManager;

    //how fast the spider moves
    [SerializeField]
    public float MoveSpeed = 4f;

    private Transform myTransform;    // reference to the object's transform

    float previousPositionX;
    public float jumpPower;
    public bool grounded = false;
    public Projectile Bullet;
    public Projectile PeaShooter;
    //rate of fire
    //[SerializeField]
    //public float FireRate = 0.5f;
    //time since last shot
    //private float FireTimer = 0.3f;
    [SerializeField]
    WeaponsContoller myWeapon;
    public bool isleft = true;
    private SpriteRenderer mySpriteRenderer;
    public float BlastCool = 0.3f;
    private float BlastTimer;
    // Use this for initialization
    void Start()
    {
        myTransform = transform;
        previousPositionX = myTransform.position.x;
        mySpriteRenderer = GetComponent<SpriteRenderer>();
        myWeapon = GetComponentInChildren<WeaponsContoller>();
        BlastTimer = 0;
    }

    // FixedUpdate is called once per physics tick/frame
    void Update()
    {
        Rigidbody2D rb2d = gameObject.GetComponent<Rigidbody2D>();

        if (Input.GetKey(KeyCode.RightArrow))
        {
            mySpriteRenderer.flipX = false;
            isleft = false;
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            mySpriteRenderer.flipX = true;
            isleft = true;
        }
        float translate = Input.GetAxis("Horizontal") * MoveSpeed;
        Vector3 horizontal = new Vector3(translate, 0, 0);
        transform.Translate(horizontal * Time.deltaTime);

        if (grounded == true)
        {
            if (Input.GetKey(KeyCode.Space))
        {
                GetComponent<Rigidbody2D>().velocity = new Vector2(GetComponent<Rigidbody2D>().velocity.x, jumpPower);
                //Bottom code causes delay jump, sorta like glide, could be useful for gliding feature
                //GetComponent<Rigidbody2D> ().position= new Vector2 (GetComponent<Rigidbody2D> ().position.x, MoveSpeed );
            }
        }
        if (Input.GetKeyDown(KeyCode.B))
        {
            MoveSpeed *= 2.0f;
        }
        else if (Input.GetKeyUp(KeyCode.B))
        {
            MoveSpeed /= 2.0f;
        }
        if (BlastTimer > 0)
        {
            BlastTimer -= Time.deltaTime;
        }
        if (BlastTimer < 0)
        {
            BlastTimer = 0;
        }

        //Detect if the fire button has been pressed.
        if (BlastTimer == 0 && Input.GetKeyDown(KeyCode.F))
        {
            Debug.Log("button was hit");

            DoWeaponFire();
        }

    }
    /*
    void UpdateFiring()
	{
			//Detect if the fire button has been pressed.
		if (BlastTimer == 0 && Input.GetKeyDown (KeyCode.F)){
				Debug.Log ("button was hit");
		
			Instantiate (Bullet, transform.position, transform.rotation);
			BlastTimer = BlastCool;
		}
} */
    void OnTriggerEnter2D(Collider2D col)
    {
        grounded = true;


        if (col.gameObject.tag == "Enemy")
        {
            levelManager.RespawnPlayer();
        }
        if (col.gameObject.tag == "EnemyProjectile")
        {
          //  levelManager.RespawnPlayer();
            Debug.Log("error3");
        }
    }

    void OnTriggerExit2D()
    {
        grounded = false;
    }
    void DoWeaponFire()
    {
        print("the \"DoWeaponFire\" function has been called");
        Instantiate(Bullet, transform.position, transform.rotation);
        BlastTimer = BlastCool;
    }

    void LateUpdate()
    {
        previousPositionX = myTransform.position.x;
    }
}
