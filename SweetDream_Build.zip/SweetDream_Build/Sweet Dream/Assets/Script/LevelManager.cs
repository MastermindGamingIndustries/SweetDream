﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour {

	public GameObject currentCheckpoint;

	private Player CupCake;

	// Use this for initialization
	void Start () {
        CupCake = FindObjectOfType<Player> ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void RespawnPlayer(){
        CupCake.transform.position = currentCheckpoint.transform.position;
		
	}
}
