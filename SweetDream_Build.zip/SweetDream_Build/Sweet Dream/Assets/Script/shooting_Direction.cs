﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shooting_Direction : MonoBehaviour {

	public float fullSpeed = 5f;
	 
	// Update is called once per frame
	void Update () {
		Vector3 pos = transform.right;
		pos.x +=  fullSpeed * Time.deltaTime;
		transform.position = pos;

	}
}
